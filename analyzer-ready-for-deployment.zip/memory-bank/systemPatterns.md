# System Patterns: פלטפורמת אימון מכירות ושירות

## 1. ארכיטקטורת המערכת

המערכת מבוססת על ארכיטקטורת Fullstack עם Next.js ל-Frontend ו-Supabase ל-Backend (Database, Auth, Storage). אינטגרציית ה-AI תתבצע דרך קריאות API ל-OpenAI.

### 1.1. מבנה תיקיות מוצע (כפי שצוין באפיון)

```
/sales-performance-gym
├── app/
│   ├── admin/                    # דשבורד ניהול כללי
│   │   ├── page.tsx              # דף ניהול ראשי (למשל, בקשות אישור)
│   │   └── users/                # עמודים לניהול משתמשים
│   │       └── page.tsx          # דף ניהול משתמשים (יצירה, רשימה)
│   ├── dashboard/                # דשבורד נציג/מנהל
│   │   └── page.tsx
│   ├── call/                     # עמודים הקשורים לשיחות ספציפיות
│   │   ├── [callId]/page.tsx     # הצגת דוח ניתוח שיחה
│   ├── upload/page.tsx           # עמוד העלאת שיחה
│   ├── login/page.tsx            # עמוד התחברות/הרשמה
│   └── layout.tsx                # Layout ראשי
├── components/                   # קומפוננטות React לשימוש חוזר
│   ├── Dashboard/
│   ├── CallAnalysis/
│   ├── UploadForm/
│   ├── Shared/
├── lib/                          # לוגיקה עסקית, התממשקות APIs
│   ├── supabase.ts               # הגדרות ופונקציות עזר ל-Supabase
│   ├── openai.ts                 # הגדרות ופונקציות עזר ל-OpenAI (Whisper, GPT)
│   ├── transcribeAudio.ts        # פונקציה לתמלול אודיו עם Whisper
│   ├── analyzeTone.ts            # פונקציה לניתוח טונציה עם GPT-4o
│   ├── analyzeCall.ts            # פונקציה לניתוח שיחה מקצועי עם GPT-4.1 Turbo
│   ├── scoring.ts                # (אופציונלי) לוגיקה לחישוב ציונים מורכבים אם נדרש
│   └── prompts/                  # (ב-MVP) פרומפטים קבועים ל-GPT - יוחלפו בקבצי MD ב-memory-bank/prompts
│       ├── salePrompt.ts         # דוגמה לפרומפט מכירה
│       ├── followupPrompt.ts     # דוגמה לפרומפט פולואפ
│       └── servicePrompt.ts      # דוגמה לפרומפט שירות
├── types/                        # הגדרות טיפוסים (TypeScript)
├── utils/                        # פונקציות עזר כלליות
├── public/                       # קבצים סטטיים
├── .env.local                    # משתני סביבה (מפתחות API וכו')
├── schema.sql                    # סכמת בסיס הנתונים (לתיעוד, Supabase Migrations ינהלו בפועל)
```

## 2. Supabase Schema

```sql
-- טבלת חברות
CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  sector TEXT,
  product_info TEXT,
  avg_product_cost TEXT, -- יכול להיות גם NUMERIC אם נרצה חישובים
  product_types TEXT[], -- מערך של טקסטים, לדוגמה: {'מוצרי מדף', 'שירותים'}
  audience TEXT, -- 'C2B' או 'B2B'
  differentiators JSONB, -- לדוגמה: {"diff1": "...", "diff2": "..."}
  customer_benefits JSONB, -- לדוגמה: {"benefit1": "...", "benefit2": "..."}
  company_benefits JSONB, -- לדוגמה: {"benefit1": "...", "benefit2": "..."}
  uploads_professional_materials BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::TEXT, now()) NOT NULL
);

-- טבלת משתמשים (public.users)
CREATE TABLE users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE, -- מפתח חיצוני לטבלת המשתמשים של Supabase Auth
  company_id UUID REFERENCES companies(id) ON DELETE SET NULL, -- ישוייך אם התפקיד הוא manager או agent
  role TEXT CHECK (role IN ('agent', 'manager', 'admin')) NOT NULL, -- התפקיד במערכת הציבורית. 'owner' הוסר לטובת 'admin' ב-system_admins ו-'manager' לחברות
  full_name TEXT,
  email TEXT UNIQUE, -- יכול להיות כפילות מ-auth.users אך נשמר כאן לנוחות גישה ו-RLS
  is_approved BOOLEAN DEFAULT FALSE, -- האם המשתמש אושר על ידי Admin (רלוונטי בעיקר ל-Managers)
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::TEXT, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::TEXT, now()) NOT NULL
);

-- טבלה למנהלי מערכת (Admins)
CREATE TABLE system_admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE, -- המזהה של המשתמש מטבלת users
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::TEXT, now()) NOT NULL
);

-- טבלת שיחות
CREATE TABLE calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE, -- לסינון קל יותר ברמת החברה
  call_type TEXT NOT NULL, -- סוג השיחה כפי שהוגדר (מכירה, פולואפ וכו')
  audio_file_path TEXT, -- נתיב לקובץ האודיו ב-Supabase Storage
  audio_duration_seconds INTEGER, -- משך השיחה בשניות
  transcript TEXT, -- התמלול המלא מ-Whisper
  analysis_report JSONB, -- הפלט המובנה מ-GPT-4.1
  overall_score NUMERIC(3,1), -- ציון כללי, למשל 8.6
  red_flag BOOLEAN DEFAULT FALSE,
  agent_notes TEXT, -- הערות שהנציג הוסיף בהעלאה
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::TEXT, now()) NOT NULL,
  analyzed_at TIMESTAMP WITH TIME ZONE
);

-- (בשלב 2) טבלת פרומפטים (אם יוחלט על ניהול דינמי)
CREATE TABLE prompts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_type TEXT UNIQUE NOT NULL,
  system_prompt TEXT NOT NULL,
  user_prompt_template TEXT, -- תבנית לפרומפט המשתמש, יכול להכיל placeholders
  parameters_schema JSONB, -- הגדרת הפרמטרים הנדרשים לניתוח סוג שיחה זה
  is_active BOOLEAN DEFAULT TRUE,
  version INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::TEXT, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE
);

-- RLS Policies (דוגמאות, יש להרחיב)
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Individuals can view their own company." ON companies FOR SELECT USING (id = (SELECT company_id FROM users WHERE id = auth.uid()));
CREATE POLICY "Owners can update their own company." ON companies FOR UPDATE USING (id = (SELECT company_id FROM users WHERE id = auth.uid() AND role = 'owner'));

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
-- Super Admins (לא מוגדר ישירות ב-RLS כאן, אלא ברמת ה-API/לוגיקה) יכולים לראות ולנהל הכל.
-- Admins יכולים לראות את כל המשתמשים, ולנהל Managers ו-Agents.
CREATE POLICY "Admins can view all users." ON users FOR SELECT
  USING (EXISTS (SELECT 1 FROM system_admins WHERE system_admins.user_id = auth.uid()));

CREATE POLICY "Admins can manage all users (except other Admins implicitly)." ON users FOR ALL
  USING (EXISTS (SELECT 1 FROM system_admins WHERE system_admins.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM system_admins WHERE system_admins.user_id = auth.uid()));

-- Managers יכולים לראות ולנהל Agents בחברה שלהם.
CREATE POLICY "Managers can view users in their company." ON users FOR SELECT
  USING (role = 'manager' AND company_id = (SELECT u.company_id FROM users u WHERE u.id = auth.uid() AND u.role = 'manager'));

CREATE POLICY "Managers can manage agents in their company." ON users FOR ALL
  USING (role = 'manager' AND company_id = (SELECT u.company_id FROM users u WHERE u.id = auth.uid() AND u.role = 'manager') AND (SELECT target.role FROM users target WHERE target.id = users.id) = 'agent') -- Manager יכול לנהל רק Agents
  WITH CHECK (role = 'manager' AND company_id = (SELECT u.company_id FROM users u WHERE u.id = auth.uid() AND u.role = 'manager') AND users.role = 'agent'); -- Manager יכול ליצור/לעדכן רק Agents

-- Agents יכולים לראות את הפרופיל של עצמם.
CREATE POLICY "Agents can view their own user record." ON users FOR SELECT
  USING (id = auth.uid() AND role = 'agent');

ALTER TABLE calls ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Agents can CRUD their own calls." ON calls FOR ALL
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Managers can view calls within their company." ON calls FOR SELECT
  USING (company_id = (SELECT company_id FROM users WHERE id = auth.uid() AND role IN ('manager', 'owner')));

```

## 3. תהליך ניתוח שיחה (AI Integration)

המערכת תציע שתי אפשרויות לניתוח שיחות, בהתאם לצורך:

### אפשרות 1: ניתוח מלא (תמלול + ניתוח טונציה + ניתוח תוכן)

1.  **העלאת שיחה:**
    *   המשתמש מעלה קובץ אודיו, בוחר `call_type` (סוג שיחה) ומזין `agent_notes` (אופציונלי).
    *   הקובץ נשמר ב-Supabase Storage. הנתיב לקובץ ומשך השיחה נשמרים בטבלת `calls`.

2.  **שלב 1: תמלול (lib/transcribeAudio.ts):**
    *   קריאה ל-API של OpenAI Whisper עם קובץ האודיו.
        ```typescript
        // lib/transcribeAudio.ts (דוגמה רעיונית)
        // const transcribeAudio = async (audioFilePath: string) => {
        //   const file = await downloadFromSupabase(audioFilePath); // או שימוש ב-URL ישיר אם אפשרי
        //   const formData = new FormData();
        //   formData.append("file", file);
        //   formData.append("model", "whisper-1"); // תמלול בלבד
        //   formData.append("language", "he");
        //   formData.append("response_format", "json"); // לקבלת segments ו-timestamps אם נדרש
        //   // ... קריאה ל-API והחזרת התמלול (data.text או מבנה מפורט יותר)
        // };
        ```
    *   התמלול (`transcript`) ומשך השיחה (`audio_duration_seconds`) נשמרים בטבלת `calls`.

3.  **שלב 2: ניתוח טונציה (lib/analyzeTone.ts):**
    *   שימוש במודל GPT-4o עם האודיו הגולמי.
    *   המטרה: לנתח טון, אנרגיה, חיוביות (positivity), ומקצועיות, וכן לזהות דגלים אדומים כמו צעקות, לחץ וחוסר סבלנות.
    *   פלט: אובייקט JSON שייקרא `tone_analysis` ויוטמע בדוח הסופי.
        ```typescript
        // lib/analyzeTone.ts (דוגמה רעיונית)
        // const analyzeCallToneWithAudio = async (audioFilePath: string, transcript: string) => {
        //   const file = await downloadFromSupabase(audioFilePath);
        //   const response = await openai.chat.completions.create({
        //     model: "gpt-4o",
        //     messages: [
        //       { 
        //          role: "system", 
        //          content: "You are an expert in analyzing conversation tone, emotion, energy, and professionalism from audio. Identify tone characteristics, emotional states, energy levels, and any signs of shouting, stress or impatience. Provide specific examples where possible." 
        //       },
        //       { 
        //          role: "user", 
        //          content: [
        //             { type: "text", text: "Analyze the tone, energy, positivity and professionalism in this audio. Also identify any red flags like shouting, stress or impatience." },
        //             { type: "audio", audio_data: file }
        //          ]
        //       },
        //     ],
        //     response_format: { type: "json_object" },
        //   });
        //   return JSON.parse(response.choices[0].message.content);
        // };
        ```

4.  **שלב 3: ניתוח תוכן מקצועי (lib/analyzeCall.ts):**
    *   שימוש במודל GPT-4.1 Turbo (`gpt-4-turbo-2024-04`).
    *   איסוף מטא-דאטה: מזהה חברה, נציג, שם חברה, קהל יעד, בידולים, תועלות, תסריטים (אם יש), חומרים מקצועיים (MVP: הזרקה ישירה), הערות הנציג.
    *   קלט: התמליל, המטא-דאטה, וסיכום ממצאי ניתוח הטונציה (`tone_analysis`) כהקשר נוסף.
    *   בחירת System/User Prompt המתאימים מ-`memory-bank/prompts/` לפי `call_type`.
    *   קריאה ל-API של OpenAI Chat Completions עם דרישת פלט JSON.
        ```typescript
        // lib/analyzeCall.ts (דוגמה רעיונית)
        // const analyzeCallContent = async (transcript: string, callType: string, metadata: any, toneAnalysisOutput: any) => {
        //   // ... טעינת פרומפטים, הזרקת מידע ...
        //   const response = await openai.chat.completions.create({
        //     model: "gpt-4-turbo-2024-04",
        //     // ... messages, response_format ...
        //   });
        //   return JSON.parse(response.choices[0].message.content);
        // };
        ```

### אפשרות 2: ניתוח טונציה ודגלים אדומים בלבד

1.  **העלאת שיחה:**
    *   המשתמש מעלה קובץ אודיו, בוחר `call_type` (סוג שיחה) ומזין `agent_notes` (אופציונלי).
    *   הקובץ נשמר ב-Supabase Storage. 

2.  **ניתוח ישיר עם GPT-4o:**
    *   שימוש במודל GPT-4o עם האודיו הגולמי.
    *   העברת האודיו ישירות לניתוח ללא שלב תמלול נפרד.
    *   בקשת ניתוח של טון, אנרגיה, חיוביות, מקצועיות וזיהוי דגלים אדומים.
        ```typescript
        // lib/directToneAnalysis.ts (דוגמה רעיונית)
        // const directToneAnalysis = async (audioFilePath: string) => {
        //   const file = await downloadFromSupabase(audioFilePath);
        //   const response = await openai.chat.completions.create({
        //     model: "gpt-4o",
        //     messages: [
        //       { 
        //          role: "system", 
        //          content: "You are an expert in analyzing conversation tone and emotional indicators directly from audio. Focus on identifying tone, energy, positivity, professionalism, and red flags like shouting, stress or impatience." 
        //       },
        //       { 
        //          role: "user", 
        //          content: [
        //             { type: "text", text: "Analyze this audio for tone, energy, positivity, professionalism and identify any red flags like shouting, stress or impatience." },
        //             { type: "audio", audio_data: file }
        //          ]
        //       },
        //     ],
        //     response_format: { type: "json_object" },
        //   });
        //   return JSON.parse(response.choices[0].message.content);
        // };
        ```

3.  **שמירת תוצאות:**
    *   הפלט מהניתוח יישמר כחלק מ-`analysis_report` בטבלת `calls`.
    *   השדות `overall_score` (אם רלוונטי) ו-`red_flag` יעודכנו בטבלת `calls`.

### שילוב התוצאות ושמירה (באפשרות 1):
*   הפלט מניתוח הטונציה (`tone_analysis`) והפלט מניתוח התוכן המקצועי (`professional_analysis`) ישולבו לאובייקט JSON אחד שיישמר בשדה `analysis_report` בטבלת `calls`.
*   השדות `overall_score` (שייקבע בעיקר על סמך הניתוח המקצועי אך יכול להיות מושפע מניתוח הטונציה) ו-`red_flag` (שיכול להיות מופעל מכל אחד משלבי הניתוח) יעודכנו בטבלת `calls`.

## פלט ניתוח (JSON לדוגמה - מבנה כללי מעודכן)
    {
      "overall_score": 8.6, // ציון משוקלל 3-10
      "red_flag": false, // true אם זוהה דגל אדום
      "red_flag_reason": null, // סיבת הדגל האדום אם קיים
      "executive_summary": "סיכום קצר של השיחה והניתוח...",
      "transcript_preview": "תחילת התמליל...", // אופציונלי, לצפייה מהירה
      "audio_duration_seconds": 350,
      "tone_analysis_report": { // פלט מניתוח הטונציה (GPT-4o)
        "overall_tone_assessment": "Neutral to slightly positive", // הערכה כללית של הטון
        "detected_emotions": ["calm", "attentive"], // רגשות שזוהו
        "energy_level": "moderate", // רמת אנרגיה (נמוכה, בינונית, גבוהה)
        "positivity": "neutral", // רמת חיוביות (שלילית, ניטרלית, חיובית)
        "professionalism": "high", // רמת מקצועיות (נמוכה, בינונית, גבוהה)
        "speaking_rate": "normal", // מהירות דיבור (מהיר, נורמלי, איטי)
        "pitch_variation": "moderate", // שינויים בגובה הקול
        "clarity_of_speech": "good", // בהירות הדיבור
        "key_tone_segments": [ // קטעים עם טונציה מיוחדת
          {
            "segment_text": "ציטוט מהשיחה...",
            "timestamp_start_seconds": 65, // אופציונלי
            "tone_description": "Slightly impatient tone noted here.",
            "emotion_detected": "impatience"
          }
        ],
        "language_alerts": { // התראות על שפה
          "profanity_detected": false,
          "aggressive_language_detected": false,
          "disrespectful_language_detected": false,
          "details": [] // אם יש, פרטים על המילים/ביטויים
        },
        "red_flags": { // דגלים אדומים טונאליים
          "shouting_detected": false,
          "high_stress_detected": false, 
          "impatience_detected": false,
          "details": [] // אם יש, פרטים על האירועים
        },
        "summary": "סיכום קצר של ניתוח הטונציה והאנרגיה..."
      },
      "categories": [ // זהו הפלט משלב ניתוח התוכן המקצועי (GPT-4.1 Turbo) - אם בוצע
        {
          "name": "שם הקטגוריה (למשל, פתיחה ובניית אמון)",
          "score": 9, // ציון לקטגוריה 3-10
          "parameters": [
            {
              "name": "שם הפרמטר (למשל, פתיח אנרגטי)",
              "score": 9, // ציון לפרמטר 3-10
              "analysis": "ניתוח מפורט של הפרמטר (2-3 משפטים).",
              "quote": "ציטוט רלוונטי מהשיחה...",
              "transcript_timestamp_seconds": 15, // אופציונלי, קישור למיקום בתמליל/שמע
              "improvement_suggestion": "איך היה צריך לנסח זאת אחרת / הצעה לשיפור..." // אם רלוונטי
            }
            // ... עוד פרמטרים בקטגוריה
          ],
          "category_summary": "סיכום קצר של ביצועי הקטגוריה."
        }
        // ... עוד קטגוריות
      ],
      "strengths_and_preservation_points": [
        "נקודת חוזק 1...",
        "נקודת חוזק 2..."
      ],
      "improvement_points": [
        "נקודה לשיפור 1...",
        "נקודה לשיפור 2..."
      ],
      "objections_in_call": [ // התנגדויות שעלו בשיחה - אם זה ניתוח מלא
        {"objection": "יקר לי", "handling_analysis": "ניתוח הטיפול בהתנגדות..."},
        {"objection": "אני צריך לחשוב על זה", "handling_analysis": "..."}
      ],
      "recommendations_for_improvement": [
        "המלצה לשיפור מקצועי 1...",
        "המלצה לשיפור מקצועי 2..."
      ],
      "recommendations_next_steps_with_customer": [ // המלצות לפעולות הבאות עם הלקוח - אם זה ניתוח מלא
        "המלצה לפעולה 1...",
        "המלצה לפעולה 2..."
      ]
    }
```

### 4. לוגיקת יצירת משתמש (Server Action - `addUser`)

תהליך יצירת משתמש חדש מתבצע דרך Server Action וכולל את השלבים הבאים, תוך התחשבות בהיררכיית התפקידים:

1.  **קבלת קלט מהטופס:**
    *   שם מלא, אימייל, סיסמה.
    *   תפקיד נבחר מהטופס (למשל, `system_admin`, `company_admin`, `agent`).
    *   מזהה חברה (`companyId`) - חובה אם התפקיד הוא `company_admin` (Manager) או `agent`.

2.  **אימות צד שרת:**
    *   בדיקה אם `companyId` סופק עבור תפקידי Manager ו-Agent.

3.  **מיפוי תפקיד מטופס לתפקיד במסד נתונים:**
    *   `system_admin` (טופס) -> `admin` (DB `users.role`)
    *   `company_admin` (טופס) -> `manager` (DB `users.role`)
    *   `agent` (טופס) -> `agent` (DB `users.role`)

4.  **יצירת משתמש ב-Supabase Auth:**
    *   שימוש ב-`supabase.auth.admin.createUser()` עם האימייל, הסיסמה, ו-`email_confirm: true` (או `false` אם מאשרים מיידית).
    *   `user_metadata` יכול להכיל את השם המלא והתפקיד הראשוני מהטופס.

5.  **הוספת רשומה לטבלת `public.users`:**
    *   לאחר יצירת המשתמש ב-Auth, הוספת רשומה לטבלת `public.users`.
    *   `id`: מזהה המשתמש שהתקבל מ-Auth.
    *   `full_name`: שם מלא.
    *   `email`: אימייל.
    *   `role`: התפקיד הממופה (DB role).
    *   `company_id`: מזהה החברה (אם רלוונטי לתפקיד Manager או Agent).
    *   `is_approved`: יכול להיות `true` כברירת מחדל עבור משתמשים שנוצרים על ידי Admin, או `false` אם נדרש אישור נוסף.

6.  **הוספה לטבלת `system_admins` (אם רלוונטי):**
    *   אם התפקיד הממופה הוא `admin`, הוספת רשומה לטבלת `system_admins` עם `user_id` של המשתמש החדש.

7.  **החזרת הודעת הצלחה/שגיאה:**
    *   ה-Server Action מחזיר אובייקט עם סטטוס הפעולה והודעה מתאימה (למשל, עבור `useFormState`).

### ניהול הרשאות וגישה:
*  **Super Admin:** בעל המערכת עם גישה מלאה, לא מוגדר ישירות דרך RLS אלא דרך לוגיקה בצד השרת או הרשאות DB מיוחדות. הוא זה שיוצר את ה-`Admin` הראשונים.
*  **Admin (מנהל מערכת פנימי):** יכול ליצור `Manager` ולשייכם לחברות. יכול ליצור `Agent` ולשייכם לחברות. יכול לראות את כל המשתמשים והחברות. ההרשאות נאכפות דרך בדיקת חברות בטבלת `system_admins` ב-RLS ובקוד.
*  **Manager (לקוח משלם/מנהל חברה):** יכול ליצור `Agent` רק עבור החברה אליה הוא משויך. מנהל את ה-`Agent` שלו. ההרשאות נאכפות דרך בדיקת `company_id` ו-`role` ב-RLS ובקוד.
*  **Agent (סוכן/נציג):** גישה מוגבלת לנתונים האישיים שלו.

מידע זה צריך להנחות את כתיבת ה-RLS policies ואת הלוגיקה ב-Server Actions ובקומפוננטות הקליינט.
